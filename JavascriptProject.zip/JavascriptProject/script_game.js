var numOfWon =0;
var numOfLost =0;

for (var i = 1;i<=5;i++){
    var guessNumber = parseInt(prompt("Enter any number from 1 to 5:"));

    var randomNumber = Math.floor(Math.random()*5) +1;
    
    if(guessNumber == randomNumber){
        document.write("<br>"+"You have won");
        numOfWon++;
    }
    else{
        document.write("<br>"+"You have lost . Random number was" +randomNumber);
        numOfLost++;
    }
}
document.write("<br>"+"Total Number of won = "+ numOfWon + "<br>");
document.write("Total Number of lost = "+ numOfLost+ "<br>");

