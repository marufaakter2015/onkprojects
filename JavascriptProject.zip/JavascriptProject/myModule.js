export let text = "welcome to module";

export function setText(txt){
    text = txt;
}