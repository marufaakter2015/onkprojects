const textOne = () => {
  console.log("Text1");
};
const dataLoading = () => {
  console.log("Text2. Data loading");

}
const textTwo = () => {
  setTimeout(dataLoading, 2000);
};
const textThree = () => {
  console.log("Text3");
};
const textFour = () => {
  console.log("Text4");
};
const textFive = () => {
  console.log("Text5");
};

textOne();
textTwo();

textThree();

textFour();

textFive();
